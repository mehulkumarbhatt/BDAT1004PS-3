﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;


namespace ConsoleApp2
{
    class Program
    {
        //Variables
        static int n, m;
        //public static object Result { get; private set; }

        static void GetTotalX(int[] a, int[] b)
        {
            for (int i = 0; i < b.Length; i++)
            {
                for (int x = 0; x < a.Length; x++)
                {
                    if ((b[i] % i) + 1 == 0)
                    {
                        Console.WriteLine("");
                    }
                }

            }
        }

        static void Main(string[] args)
        {
            TextWriter textWriter = new StreamWriter(@System.Environment.GetEnvironmentVariable("OUTPUT_PATH"), true);

            string[] firstMultipleInput = Console.ReadLine().TrimEnd().Split(' ');

            //First Element
            int n = Convert.ToInt32(firstMultipleInput[0]);
            //Second Element
            int m = Convert.ToInt32(firstMultipleInput[1]);

            string[] input1 = Console.ReadLine().TrimEnd().Split(' ');
            int[] array1 = Array.ConvertAll(input1, Int32.Parse);

            string[] input2 = Console.ReadLine().TrimEnd().Split(' ');
            int[] array2 = Array.ConvertAll(input2, Int32.Parse);

            GetTotalX(array1, array2);

            textWriter.WriteLine();

            textWriter.Flush();
            textWriter.Close();
        }
    }
}
